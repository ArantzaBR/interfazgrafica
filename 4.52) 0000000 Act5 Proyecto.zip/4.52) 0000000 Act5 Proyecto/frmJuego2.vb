﻿Public Class frmJuego2
    Dim v1, v2, v3, v4 As Integer

    Private Sub btnVolver_Click(sender As Object, e As EventArgs) Handles btnVolver.Click
        frmMain.Show()
        Me.Hide()

    End Sub

    Private Sub btnEmpezar_Click(sender As Object, e As EventArgs) Handles btnEmpezar.Click
        pbCab1.Left = 12
        pbCab2.Left = 12
        pbCab3.Left = 12
        pbCab4.Left = 12
        Timer1.Enabled = True
        Timer2.Enabled = True
        Timer3.Enabled = True
        Timer4.Enabled = True
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        v1 = Math.Round(Rnd() * 20 + 5)
        pbCab1.Left = pbCab1.Left + v1
        If pbCab1.Left >= 515 Then
            Timer1.Enabled = False
            Timer2.Enabled = False
            Timer3.Enabled = False
            Timer4.Enabled = False
            MsgBox("El  caballo 1 ganó la carrera", vbInformation, "Casino Humilde")
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        v2 = Math.Round(Rnd() * 20 + 5)
        pbCab2.Left = pbCab2.Left + v2
        If pbCab2.Left >= 515 Then
            Timer1.Enabled = False
            Timer2.Enabled = False
            Timer3.Enabled = False
            Timer4.Enabled = False
            MsgBox("El Caballo 2 ganó la carrera", vbInformation, "Casino Humilde")
        End If
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        v3 = Math.Round(Rnd() * 20 + 5)
        pbCab3.Left = pbCab3.Left + v3
        If pbCab3.Left >= 515 Then
            Timer1.Enabled = False
            Timer2.Enabled = False
            Timer3.Enabled = False
            Timer4.Enabled = False
            MsgBox("El caballo 3 ganó la carrera", vbInformation, "Casino Humilde")
        End If
    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        v4 = Math.Round(Rnd() * 20 + 5)
        pbCab4.Left = pbCab4.Left + v4
        If pbCab4.Left >= 515 Then
            Timer1.Enabled = False
            Timer2.Enabled = False
            Timer3.Enabled = False
            Timer4.Enabled = False
            MsgBox("El caballo 4 ganó la carrera", vbInformation, "Casino Humilde")
        End If
    End Sub

    Private Sub frmJuego2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class