﻿Public Class frmLogin
    Dim nIntentos As Integer = 0
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim salir As String = MsgBox("Desea Salir?", vbYesNo, "Salir")
        If salir = vbYes Then
            Me.Close()

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If nIntentos >= 5 Then
            MsgBox("A Alcanzado el máximo de Intentos", vbCritical, "Login")
            Me.Close()
        End If
        If txtUsuario.Text = "Manuel" Then
            If txtContraseña.Text = "123" Then
                MsgBox(" Bienvenido " & txtUsuario.Text, vbInformation, "Login")
                Me.Hide()
                frmMain.Show()
            Else
                MsgBox("Contraseña Invalida", vbCritical, "Login")
            End If
        Else
            MsgBox("Usuario no Encontrado", vbCritical, "Login")
        End If

        nIntentos += 1

    End Sub

    Private Sub frmLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
