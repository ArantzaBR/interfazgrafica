﻿Public Class frmMain
    Private Sub InicioToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InicioToolStripMenuItem.Click
        frmInicio.Show()
        Me.Hide()
    End Sub
    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click

        End


    End Sub

    Private Sub Juego1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Juego1ToolStripMenuItem.Click
        frmJuego1.Show()
        Me.Hide()
    End Sub

    Private Sub Juego2ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Juego2ToolStripMenuItem.Click
        frmJuego2.Show()
        Me.Hide()

    End Sub

    Private Sub AcercaSobreToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AcercaSobreToolStripMenuItem.Click
        frmAcerca_de.Show()
        Me.Hide()


    End Sub

    Private Sub ManualToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ManualToolStripMenuItem.Click
        Form1.Show()
        Me.Hide()

    End Sub

End Class