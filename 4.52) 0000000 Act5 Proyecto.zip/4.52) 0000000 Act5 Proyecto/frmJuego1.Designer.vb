﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmJuego1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(frmJuego1))
        lblNo1 = New Label()
        lblNo2 = New Label()
        lblNo3 = New Label()
        btnJugar = New Button()
        btnReiniciar = New Button()
        btnVolver = New Button()
        Label4 = New Label()
        Label1 = New Label()
        lbl2 = New Label()
        l1 = New Label()
        l2 = New Label()
        l3 = New Label()
        SuspendLayout()
        ' 
        ' lblNo1
        ' 
        lblNo1.AutoSize = True
        lblNo1.Font = New Font("Segoe UI Emoji", 69.75F, FontStyle.Bold, GraphicsUnit.Point)
        lblNo1.Location = New Point(31, 9)
        lblNo1.Name = "lblNo1"
        lblNo1.Size = New Size(0, 123)
        lblNo1.TabIndex = 0
        ' 
        ' lblNo2
        ' 
        lblNo2.AutoSize = True
        lblNo2.Font = New Font("Segoe UI", 69.75F, FontStyle.Regular, GraphicsUnit.Point)
        lblNo2.Location = New Point(177, 9)
        lblNo2.Name = "lblNo2"
        lblNo2.Size = New Size(0, 124)
        lblNo2.TabIndex = 1
        ' 
        ' lblNo3
        ' 
        lblNo3.AutoSize = True
        lblNo3.Font = New Font("Segoe UI", 69.75F, FontStyle.Regular, GraphicsUnit.Point)
        lblNo3.Location = New Point(314, 9)
        lblNo3.Name = "lblNo3"
        lblNo3.Size = New Size(0, 124)
        lblNo3.TabIndex = 2
        ' 
        ' btnJugar
        ' 
        btnJugar.Location = New Point(31, 165)
        btnJugar.Name = "btnJugar"
        btnJugar.Size = New Size(385, 36)
        btnJugar.TabIndex = 3
        btnJugar.Text = "&Jugar"
        btnJugar.UseVisualStyleBackColor = True
        ' 
        ' btnReiniciar
        ' 
        btnReiniciar.Location = New Point(31, 207)
        btnReiniciar.Name = "btnReiniciar"
        btnReiniciar.Size = New Size(385, 38)
        btnReiniciar.TabIndex = 4
        btnReiniciar.TabStop = False
        btnReiniciar.Text = "&Reiniciar"
        btnReiniciar.UseVisualStyleBackColor = True
        ' 
        ' btnVolver
        ' 
        btnVolver.Location = New Point(319, 288)
        btnVolver.Name = "btnVolver"
        btnVolver.Size = New Size(122, 30)
        btnVolver.TabIndex = 5
        btnVolver.Text = "&Volver"
        btnVolver.UseVisualStyleBackColor = True
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(27, 288)
        Label4.Name = "Label4"
        Label4.Size = New Size(82, 15)
        Label4.TabIndex = 6
        Label4.Text = "# de Intentos: "
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(115, 275)
        Label1.Name = "Label1"
        Label1.Size = New Size(0, 15)
        Label1.TabIndex = 7
        ' 
        ' lbl2
        ' 
        lbl2.AutoSize = True
        lbl2.Location = New Point(115, 288)
        lbl2.Name = "lbl2"
        lbl2.Size = New Size(41, 15)
        lbl2.TabIndex = 9
        lbl2.Text = "Label2"
        ' 
        ' l1
        ' 
        l1.AutoSize = True
        l1.Font = New Font("Segoe UI", 69.75F, FontStyle.Regular, GraphicsUnit.Point)
        l1.Location = New Point(37, 9)
        l1.Name = "l1"
        l1.Size = New Size(102, 124)
        l1.TabIndex = 10
        l1.Text = "0"
        ' 
        ' l2
        ' 
        l2.AutoSize = True
        l2.Font = New Font("Segoe UI", 69.75F, FontStyle.Regular, GraphicsUnit.Point)
        l2.Location = New Point(177, 8)
        l2.Name = "l2"
        l2.Size = New Size(102, 124)
        l2.TabIndex = 11
        l2.Text = "0"
        ' 
        ' l3
        ' 
        l3.AutoSize = True
        l3.Font = New Font("Segoe UI", 69.75F, FontStyle.Regular, GraphicsUnit.Point)
        l3.Location = New Point(314, 8)
        l3.Name = "l3"
        l3.Size = New Size(102, 124)
        l3.TabIndex = 12
        l3.Text = "0"
        ' 
        ' frmJuego1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        AutoSizeMode = AutoSizeMode.GrowAndShrink
        BackgroundImage = My.Resources.Resources.casino_juego_1
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(474, 335)
        Controls.Add(l3)
        Controls.Add(l2)
        Controls.Add(l1)
        Controls.Add(lbl2)
        Controls.Add(Label1)
        Controls.Add(Label4)
        Controls.Add(btnVolver)
        Controls.Add(btnReiniciar)
        Controls.Add(btnJugar)
        Controls.Add(lblNo3)
        Controls.Add(lblNo2)
        Controls.Add(lblNo1)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Name = "frmJuego1"
        StartPosition = FormStartPosition.CenterScreen
        Text = "frmJuego1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblNo1 As Label
    Friend WithEvents lblNo2 As Label
    Friend WithEvents lblNo3 As Label
    Friend WithEvents btnJugar As Button
    Friend WithEvents btnReiniciar As Button
    Friend WithEvents btnVolver As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents l1 As Label
    Friend WithEvents l2 As Label
    Friend WithEvents l3 As Label
End Class
