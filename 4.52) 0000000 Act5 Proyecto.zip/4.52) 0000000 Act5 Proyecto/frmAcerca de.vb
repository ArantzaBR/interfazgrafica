﻿Public Class frmAcerca_de
    Private Sub btnBolver_Click(sender As Object, e As EventArgs) Handles btnBolver.Click
        frmMain.Show()
        Me.Hide()

    End Sub
End Class