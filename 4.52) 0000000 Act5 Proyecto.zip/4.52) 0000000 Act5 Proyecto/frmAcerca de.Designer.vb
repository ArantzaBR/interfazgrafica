﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAcerca_de
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(frmAcerca_de))
        Label1 = New Label()
        btnBolver = New Button()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(128))
        Label1.Font = New Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(164, 50)
        Label1.Name = "Label1"
        Label1.Size = New Size(89, 19)
        Label1.TabIndex = 0
        Label1.Text = "Acerca de"
        ' 
        ' btnBolver
        ' 
        btnBolver.Location = New Point(173, 264)
        btnBolver.Name = "btnBolver"
        btnBolver.Size = New Size(112, 28)
        btnBolver.TabIndex = 1
        btnBolver.Text = "&Volver"
        btnBolver.UseVisualStyleBackColor = True
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(51, 59)
        Label2.Name = "Label2"
        Label2.Size = New Size(0, 15)
        Label2.TabIndex = 2
        Label2.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(128))
        Label3.Location = New Point(21, 91)
        Label3.Name = "Label3"
        Label3.Size = New Size(410, 15)
        Label3.TabIndex = 3
        Label3.Text = "Este casino virtual fue creado con el objetivo de que las personas se diviertan"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(128))
        Label4.Location = New Point(21, 106)
        Label4.Name = "Label4"
        Label4.Size = New Size(194, 15)
        Label4.TabIndex = 4
        Label4.Text = "Este casino cuenta con lo siguiente:"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(128))
        Label5.Location = New Point(21, 121)
        Label5.Name = "Label5"
        Label5.Size = New Size(230, 15)
        Label5.TabIndex = 5
        Label5.Text = "-El casino tiene una seccion de bienvenida"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(128))
        Label6.Location = New Point(21, 136)
        Label6.Name = "Label6"
        Label6.Size = New Size(285, 15)
        Label6.TabIndex = 6
        Label6.Text = "-Cuenta con un Manual por si el jugador tiene dudas"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(128))
        Label7.Location = New Point(21, 151)
        Label7.Name = "Label7"
        Label7.Size = New Size(301, 15)
        Label7.TabIndex = 7
        Label7.Text = "-En la sección de juegos, se podra elegir el juego a jugar"
        ' 
        ' frmAcerca_de
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        AutoSizeMode = AutoSizeMode.GrowAndShrink
        BackgroundImage = My.Resources.Resources.Fondo_casino
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(438, 327)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(btnBolver)
        Controls.Add(Label1)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimizeBox = False
        Name = "frmAcerca_de"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Casino Humilde"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents btnBolver As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
End Class
