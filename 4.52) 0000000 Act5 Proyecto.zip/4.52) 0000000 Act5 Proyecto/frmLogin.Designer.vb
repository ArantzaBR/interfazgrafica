﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(frmLogin))
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Button1 = New Button()
        Button2 = New Button()
        txtUsuario = New TextBox()
        txtContraseña = New TextBox()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Tahoma", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(103, 26)
        Label1.Name = "Label1"
        Label1.Size = New Size(120, 19)
        Label1.TabIndex = 0
        Label1.Text = "Login Usuario"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Tahoma", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.ForeColor = Color.Black
        Label2.Location = New Point(33, 75)
        Label2.Name = "Label2"
        Label2.Size = New Size(112, 19)
        Label2.TabIndex = 1
        Label2.Text = "Usuario       :"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Tahoma", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = Color.Black
        Label3.Location = New Point(27, 156)
        Label3.Name = "Label3"
        Label3.Size = New Size(118, 19)
        Label3.TabIndex = 2
        Label3.Text = "Contraseña  :"
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Tahoma", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.Location = New Point(49, 223)
        Button1.Name = "Button1"
        Button1.Size = New Size(96, 32)
        Button1.TabIndex = 3
        Button1.Text = "&Ingresar"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Font = New Font("Tahoma", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.Location = New Point(199, 223)
        Button2.Name = "Button2"
        Button2.Size = New Size(96, 32)
        Button2.TabIndex = 4
        Button2.Text = "&Salir"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' txtUsuario
        ' 
        txtUsuario.Font = New Font("Tahoma", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        txtUsuario.Location = New Point(166, 72)
        txtUsuario.Name = "txtUsuario"
        txtUsuario.Size = New Size(152, 27)
        txtUsuario.TabIndex = 5
        ' 
        ' txtContraseña
        ' 
        txtContraseña.Font = New Font("Tahoma", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        txtContraseña.Location = New Point(166, 153)
        txtContraseña.Name = "txtContraseña"
        txtContraseña.PasswordChar = "*"c
        txtContraseña.Size = New Size(152, 27)
        txtContraseña.TabIndex = 6
        ' 
        ' frmLogin
        ' 
        AutoScaleDimensions = New SizeF(7.0F, 15.0F)
        AutoScaleMode = AutoScaleMode.Font
        AutoSizeMode = AutoSizeMode.GrowAndShrink
        BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(128))
        ClientSize = New Size(343, 298)
        Controls.Add(txtContraseña)
        Controls.Add(txtUsuario)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        ForeColor = Color.Black
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimizeBox = False
        Name = "frmLogin"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Login"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents txtUsuario As TextBox
    Friend WithEvents txtContraseña As TextBox
End Class
