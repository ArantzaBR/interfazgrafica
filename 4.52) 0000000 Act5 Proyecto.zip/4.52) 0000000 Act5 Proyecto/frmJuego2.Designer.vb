﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmJuego2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(frmJuego2))
        btnEmpezar = New Button()
        btnVolver = New Button()
        pbCab1 = New PictureBox()
        pbCab2 = New PictureBox()
        pbCab3 = New PictureBox()
        pbCab4 = New PictureBox()
        pbMeta = New PictureBox()
        Timer1 = New Timer(components)
        Timer2 = New Timer(components)
        Timer3 = New Timer(components)
        Timer4 = New Timer(components)
        CType(pbCab1, ComponentModel.ISupportInitialize).BeginInit()
        CType(pbCab2, ComponentModel.ISupportInitialize).BeginInit()
        CType(pbCab3, ComponentModel.ISupportInitialize).BeginInit()
        CType(pbCab4, ComponentModel.ISupportInitialize).BeginInit()
        CType(pbMeta, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' btnEmpezar
        ' 
        btnEmpezar.Location = New Point(467, 12)
        btnEmpezar.Name = "btnEmpezar"
        btnEmpezar.Size = New Size(174, 39)
        btnEmpezar.TabIndex = 0
        btnEmpezar.Text = "&Empezar"
        btnEmpezar.UseVisualStyleBackColor = True
        ' 
        ' btnVolver
        ' 
        btnVolver.Location = New Point(12, 12)
        btnVolver.Name = "btnVolver"
        btnVolver.Size = New Size(150, 39)
        btnVolver.TabIndex = 1
        btnVolver.Text = "&Volver"
        btnVolver.UseVisualStyleBackColor = True
        ' 
        ' pbCab1
        ' 
        pbCab1.Image = My.Resources.Resources.Caballo_1
        pbCab1.Location = New Point(12, 78)
        pbCab1.Name = "pbCab1"
        pbCab1.Size = New Size(100, 59)
        pbCab1.SizeMode = PictureBoxSizeMode.StretchImage
        pbCab1.TabIndex = 2
        pbCab1.TabStop = False
        ' 
        ' pbCab2
        ' 
        pbCab2.Image = My.Resources.Resources.Caballo_2
        pbCab2.Location = New Point(12, 152)
        pbCab2.Name = "pbCab2"
        pbCab2.Size = New Size(100, 50)
        pbCab2.SizeMode = PictureBoxSizeMode.StretchImage
        pbCab2.TabIndex = 3
        pbCab2.TabStop = False
        ' 
        ' pbCab3
        ' 
        pbCab3.Image = My.Resources.Resources.Caballo_3
        pbCab3.Location = New Point(12, 221)
        pbCab3.Name = "pbCab3"
        pbCab3.Size = New Size(100, 50)
        pbCab3.SizeMode = PictureBoxSizeMode.StretchImage
        pbCab3.TabIndex = 4
        pbCab3.TabStop = False
        ' 
        ' pbCab4
        ' 
        pbCab4.Image = My.Resources.Resources.Caballo_4
        pbCab4.Location = New Point(12, 281)
        pbCab4.Name = "pbCab4"
        pbCab4.Size = New Size(100, 50)
        pbCab4.SizeMode = PictureBoxSizeMode.StretchImage
        pbCab4.TabIndex = 5
        pbCab4.TabStop = False
        ' 
        ' pbMeta
        ' 
        pbMeta.Image = My.Resources.Resources.meta
        pbMeta.Location = New Point(575, 71)
        pbMeta.Name = "pbMeta"
        pbMeta.Size = New Size(41, 266)
        pbMeta.TabIndex = 6
        pbMeta.TabStop = False
        ' 
        ' Timer1
        ' 
        ' 
        ' Timer2
        ' 
        ' 
        ' Timer3
        ' 
        ' 
        ' Timer4
        ' 
        ' 
        ' frmJuego2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        AutoSizeMode = AutoSizeMode.GrowAndShrink
        ClientSize = New Size(664, 343)
        Controls.Add(pbCab4)
        Controls.Add(pbCab3)
        Controls.Add(pbCab2)
        Controls.Add(pbCab1)
        Controls.Add(btnVolver)
        Controls.Add(btnEmpezar)
        Controls.Add(pbMeta)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimizeBox = False
        Name = "frmJuego2"
        StartPosition = FormStartPosition.CenterScreen
        Text = "frmJuego2"
        CType(pbCab1, ComponentModel.ISupportInitialize).EndInit()
        CType(pbCab2, ComponentModel.ISupportInitialize).EndInit()
        CType(pbCab3, ComponentModel.ISupportInitialize).EndInit()
        CType(pbCab4, ComponentModel.ISupportInitialize).EndInit()
        CType(pbMeta, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents btnEmpezar As Button
    Friend WithEvents btnVolver As Button
    Friend WithEvents pbCab1 As PictureBox
    Friend WithEvents pbCab2 As PictureBox
    Friend WithEvents pbCab3 As PictureBox
    Friend WithEvents pbCab4 As PictureBox
    Friend WithEvents pbMeta As PictureBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Timer3 As Timer
    Friend WithEvents Timer4 As Timer
End Class
