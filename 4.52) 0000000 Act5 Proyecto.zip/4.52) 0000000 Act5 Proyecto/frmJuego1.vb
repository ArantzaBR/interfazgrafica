﻿Public Class frmJuego1
    Private Sub btnVolver_Click(sender As Object, e As EventArgs) Handles btnVolver.Click
        frmMain.Show()
        Me.Hide()

    End Sub

    Private Sub frmJuego1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()
        lbl2.Text = 15


    End Sub

    Private Sub btnJugar_Click(sender As Object, e As EventArgs) Handles btnJugar.Click
        l1.Text = Int(7 * Rnd() + 1)
        l2.Text = Int(7 * Rnd() + 1)
        l3.Text = Int(7 * Rnd() + 1)

        lbl2.Text = lbl2.Text - 1

        If l1.Text = l2.Text And l1.Text = l3.Text Then
            MsgBox("Felicidades, ganaste")
            lbl2.Text = lbl2.Text + 1
        End If
        If lbl2.Text = 0 Then
            MsgBox("Te quedaste sin turnos")
            btnJugar.Enabled = False
        End If
    End Sub

    Private Sub btnReiniciar_Click(sender As Object, e As EventArgs) Handles btnReiniciar.Click
        l1.Text = ""
        l2.Text = ""
        l3.Text = ""
        btnJugar.Enabled = True
        lbl2.Text = 15
    End Sub
End Class